package com.gl.feb.ElectricityBill.service;

import com.gl.feb.ElectricityBill.entity.BillCompany;
import com.gl.feb.ElectricityBill.repository.BillCompanyRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class BillCompanyServiceImpl implements BillCompanyService{

   @Autowired
   BillCompanyRepo billCompanyRepo;

    @Override
    public void save(BillCompany billCompany) {
        System.out.println("saving billCompany details");
        billCompanyRepo.save(billCompany);
    }

    @Override
    public BillCompany getByName(String companyName) {
        return billCompanyRepo.findByName(companyName).get();
    }
}
