package com.gl.feb.ElectricityBill.service;

import com.gl.feb.ElectricityBill.entity.BillCompany;

import java.util.Optional;

public interface BillCompanyService {

    void save(BillCompany billCompany);

    BillCompany getByName(String companyName);
}
