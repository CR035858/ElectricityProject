package com.gl.feb.ElectricityBill.service;

import com.gl.feb.ElectricityBill.models.GenerateBillRequest;
import com.gl.feb.ElectricityBill.models.GeneratedBillResponse;
import org.springframework.stereotype.Service;

@Service
public class BillServiceImpl implements BillService {


    @Override
    public GeneratedBillResponse generateBill(GenerateBillRequest generateBillRequest) {

        System.out.println("Saved DATA in process");
        return new GeneratedBillResponse();
    }
}
