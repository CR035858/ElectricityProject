package com.gl.feb.ElectricityBill.service;

import com.gl.feb.ElectricityBill.Mapper.UserMapper;
import com.gl.feb.ElectricityBill.entity.BillCompany;
import com.gl.feb.ElectricityBill.entity.User;
import com.gl.feb.ElectricityBill.models.UserDetailsRequest;
import com.gl.feb.ElectricityBill.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService{


    @Autowired
    UserRepo userRepo;
    @Autowired
    BillCompanyService billCompanyService;

    @Override
    public void save(UserDetailsRequest userDetailsRequest) {

        BillCompany billCompany = billCompanyService.getByName(userDetailsRequest.getCompanyName());
        userRepo.save(UserMapper.toUser(userDetailsRequest, billCompany));
    }
}
