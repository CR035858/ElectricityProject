package com.gl.feb.ElectricityBill.repository;


import com.gl.feb.ElectricityBill.entity.BillDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BillDetailsRepo extends JpaRepository<BillDetails, Integer> {

}
