package com.gl.feb.ElectricityBill.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "bill_company")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BillCompany {

    @Id
    @GeneratedValue(strategy =  GenerationType.AUTO)
    int id;

    @Column(name = "user_name")
    private String userName;

    @Column(name="price_per_unit")
    Double pricePerUnit;

}
