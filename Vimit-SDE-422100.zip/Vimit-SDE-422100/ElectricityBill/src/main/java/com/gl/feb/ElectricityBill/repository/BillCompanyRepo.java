package com.gl.feb.ElectricityBill.repository;

import com.gl.feb.ElectricityBill.entity.BillCompany;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface BillCompanyRepo extends JpaRepository<BillCompany, Integer> {

  //  Optional<BillCompany> findByName(String name);
    Optional<BillCompany> findByUserName(String userName);

}
