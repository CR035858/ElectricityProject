package com.gl.feb.ElectricityBill.controller;

import com.gl.feb.ElectricityBill.models.GenerateBillRequest;

import com.gl.feb.ElectricityBill.service.BillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/bill")
public class BillController {

    @Autowired
    BillService billService;

    @GetMapping("/invoke")
    public  String invoke(Model model) {
        model.addAttribute("generateBillRequest",new GenerateBillRequest());
        return "generate_bill";

    }

    @PostMapping("/generate")
    public String generateBill(@ModelAttribute("generateBillRequest") GenerateBillRequest generateBillRequest) {

        billService.generateBill(generateBillRequest);

        return "success";
    }
}
