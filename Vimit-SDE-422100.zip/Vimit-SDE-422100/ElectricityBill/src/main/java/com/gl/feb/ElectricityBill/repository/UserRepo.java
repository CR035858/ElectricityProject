package com.gl.feb.ElectricityBill.repository;

import com.gl.feb.ElectricityBill.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepo extends JpaRepository <User,Integer> {


}
