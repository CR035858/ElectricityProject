package com.gl.feb.ElectricityBill.service;

import com.gl.feb.ElectricityBill.models.GenerateBillRequest;
import com.gl.feb.ElectricityBill.models.GeneratedBillResponse;

public interface BillService {

    public GeneratedBillResponse generateBill(GenerateBillRequest generateBillRequest);
}
